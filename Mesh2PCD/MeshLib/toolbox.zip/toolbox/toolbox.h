#pragma once
#include "DebugSetting.h"
#include "iterFunc.h"