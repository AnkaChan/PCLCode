#include<iostream>
#include<functional>
#include "..\core\Mesh\Vertex.h"
#include "..\core\Mesh\Edge.h"
#include "..\core\Mesh\Face.h"
#include "..\core\Mesh\HalfEdge.h"
#include "..\core\Mesh\BaseMesh.h"
#include "..\core\Mesh\iterators.h"
#include "..\core\Mesh\boundary.h"
#include "..\core\Parser\parser.h"

using std::cout;
using std::endl;

namespace MeshLib {
	template<typename V, typename E, typename F, typename H>
	class MeshToolBox {
	public:
		typedef CBoundary<V, E, F, H>					CBoundary;
		typedef CLoop<V, E, F, H>						CLoop;

		typedef MeshVertexIterator<V, E, F, H>			MeshVertexIterator;
		typedef MeshEdgeIterator<V, E, F, H>			MeshEdgeIterator;
		typedef MeshFaceIterator<V, E, F, H>			MeshFaceIterator;
		typedef MeshHalfEdgeIterator<V, E, F, H>		MeshHalfEdgeIterator;

		typedef VertexVertexIterator<V, E, F, H>		VertexVertexIterator;
		typedef VertexEdgeIterator<V, E, F, H>			VertexEdgeIterator;
		typedef VertexFaceIterator<V, E, F, H>			VertexFaceIterator;
		typedef VertexInHalfedgeIterator<V, E, F, H>	VertexInHalfedgeIterator;
		typedef VertexOutHalfedgeIterator<V, E, F, H>	VertexOutHalfedgeIterator;

		typedef FaceVertexIterator<V, E, F, H>			FaceVertexIterator;
		typedef FaceEdgeIterator<V, E, F, H>			FaceEdgeIterator;
		typedef FaceHalfedgeIterator<V, E, F, H>		FaceHalfedgeIterator;
		typedef CBaseMesh<V, E, F, H> CMesh;
		//Vertex
		static void MeshVertexIterFunc(CMesh *pMesh, std::function<void(V*)> VFunc) {
			for (MeshVertexIterator MVIter(pMesh); !MVIter.end(); ++MVIter) {
				VFunc(*MVIter);
			}
		};
		static MeshVertexIterator MeshVertexIterFuncCondition(CMesh *pMesh, std::function<bool(V*)> VFunc) {
			MeshVertexIterator MVIter(pMesh);
			for (; !MVIter.end(); ++MVIter) {
				if ( !VFunc(*MVIter) )
					return MVIter;
			}
			return MVIter;
		};
		//Face
		static void MeshFaceIterFunc(CMesh *pMesh, std::function<void(F*)> FFunc) {
			for (MeshFaceIterator MFITer(pMesh); !MFITer.end(); ++MFITer) {
				FFunc(*MFITer);
			}
		};
		static MeshFaceIterator MeshFaceIterFuncCondition(CMesh *pMesh, std::function<bool(F*)> FFunc) {
			MeshFaceIterator MFIter(pMesh);
			for (; !MFIter.end(); ++MFIter) {
				if (!FFunc(*MFIter))
					return MFIter;
			}
			return MFIter;
		};
		//Edge
		static void MeshEdgeIterFunc(CMesh *pMesh, std::function<void(E*)> EFunc) {
			for (MeshEdgeIterator MEIter(pMesh); !MEIter.end(); ++MEIter) {
				EFunc(*MEIter);
			}
		};
		static MeshEdgeIterator MeshEdgeIterFuncCondition(CMesh *pMesh, std::function<bool(E*)> FFunc) {
			MeshEdgeIterator MEIter(pMesh);
			for (; !MEIter.end(); ++MEIter) {
				if (!FFunc(*MEIter))
					return MEIter;
			}
			return MEIter;
		};
		//basic for_each template
		template<typename IterType, typename IterCenterClass, typename IterClass>
		static void IterEachFunc(IterCenterClass *pObj, std::function<void(IterClass*)> Func) {		
			for (IterType Iter(pObj); !Iter.end(); ++Iter) {
				Func(*Iter);
			}
		}
		template<typename IterType, typename IterCenterClass, typename IterClass>
		static void IterEachFuncWithPMesh(CMesh *pMesh, IterCenterClass *pObj, std::function<void(IterClass*)> Func) {
			for (IterType Iter(pMesh, pObj); !Iter.end(); ++Iter) {
				Func(*Iter);
			}
		}
		template<typename IterType, typename IterCenterClass, typename IterClass>
		static typename IterType IterEachFuncCondition(IterCenterClass *pObj, std::function<bool(IterClass*)> Func) {
			IterType Iter(pObj);
			for (; !Iter.end(); ++Iter) {
				if (!Func(*Iter)) {
					return Iter;
				}
			}
			return Iter;
		}
		template<typename IterType, typename IterCenterClass, typename IterClass>
		static typename IterType IterEachFuncConditionWithPMesh(CMesh *pMesh, IterCenterClass *pObj, std::function<bool(IterClass*)> Func) {
			IterType Iter(pMesh, pObj);
			for (; !Iter.end(); ++Iter) {
				if (!Func(*Iter)) {
					return Iter;
				}
			}
			return Iter;
		}
		//vertex
		static constexpr auto VertexEdgeIterFunc = IterEachFunc<VertexEdgeIterator, CVertex, CEdge>;
		static constexpr auto VertexFaceIterFunc = IterEachFunc<VertexFaceIterator, CVertex, CFace>;
		static constexpr auto VertexVertexIterFun = IterEachFunc<VertexVertexIterator, CVertex, CVertex>;
		static constexpr auto VertexInHalfEdgeIterFun = IterEachFuncWithPMesh<VertexInHalfedgeIterator, CVertex, CHalfEdge>;
		static constexpr auto VertexOutHalfEdgeIterFun = IterEachFuncWithPMesh<VertexOutHalfedgeIterator, CVertex, CHalfEdge>;

		static constexpr auto VertexEdgeIterFuncCondition = IterEachFuncCondition<VertexEdgeIterator, CVertex, CEdge>;
		static constexpr auto VertexFaceIterFuncCondition = IterEachFuncCondition<VertexFaceIterator, CVertex, CFace>;
		static constexpr auto VertexVertexIterFunCondition = IterEachFuncCondition<VertexVertexIterator, CVertex, CVertex>;
		static constexpr auto VertexInHalfEdgeIterFunCondition = IterEachFuncConditionWithPMesh<VertexInHalfedgeIterator, CVertex, CHalfEdge>;
		static constexpr auto VertexOutHalfEdgeIterFunCondition = IterEachFuncConditionWithPMesh<VertexOutHalfedgeIterator, CVertex, CHalfEdge>;
		//face
		static constexpr auto FaceVertexIterFunc = IterEachFunc<FaceVertexIterator, CFace, CVertex>;
		static constexpr auto FaceEdgeIterFunc = IterEachFunc<FaceEdgeIterator, CFace, CEdge>;
		static constexpr auto FaceHalfEdgeIterFunc = IterEachFunc<FaceHalfedgeIterator, CFace, CHalfEdge>;

		static constexpr auto FaceVertexIterFuncCondition = IterEachFuncCondition<FaceVertexIterator, CFace, CVertex>;
		static constexpr auto FaceEdgeIterFuncCondition = IterEachFuncCondition<FaceEdgeIterator, CFace, CEdge>;
		static constexpr auto FaceHalfEdgeIterFuncCondition = IterEachFuncCondition<FaceHalfedgeIterator, CFace, CHalfEdge>;

	};
}